/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aafanasy <aafanasy@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/19 00:48:35 by aafanasy          #+#    #+#             */
/*   Updated: 2026/07/19 01:13:41 by aafanasy         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush02.h"

int	ft_parse_args(int argc, char **argv, char **dict_path, char **num_str)
{
	if (argc == 2)
	{
		*dict_path = "numbers.dict";
		*num_str = argv[1];
		return (1);
	}
	else if (argc == 3)
	{
		*dict_path = argv[1];
		*num_str = argv[2];
		return (1);
	}
	return (0);
}

void	ft_execute(char *num_str, t_dict *dict, t_lang rules)
{
	if (!ft_validate_dict(dict))
	{
		ft_putstr("Dict Error\n");
		return ;
	}
	if (ft_strcmp(num_str, "-") == 0)
		ft_process_stdin(dict, rules);
	else if (!ft_str_is_numeric(num_str))
		ft_putstr("Error\n");
	else
	{
		while (*num_str == '0' && *(num_str + 1) != '\0')
			num_str++;
		ft_convert_and_print(num_str, dict, rules);
	}
}

int	main(int argc, char **argv)
{
	char	*dict_path;
	char	*num_str;
	t_dict	*dict;
	t_lang	rules;

	if (!ft_parse_args(argc, argv, &dict_path, &num_str))
	{
		ft_putstr("Error\n");
		return (0);
	}
	dict = ft_parse_dictionary(dict_path);
	if (!dict)
	{
		ft_putstr("Dict Error\n");
		return (0);
	}
	rules = ft_init_lang_rules(dict_path);
	ft_execute(num_str, dict, rules);
	ft_free_dictionary(dict);
	return (0);
}
