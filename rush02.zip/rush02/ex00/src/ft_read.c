/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_read.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aafanasy <aafanasy@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/19 00:59:31 by aafanasy          #+#    #+#             */
/*   Updated: 2026/07/19 00:59:35 by aafanasy         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush02.h"

int	ft_get_file_size(char *filepath)
{
	int		fd;
	int		size;
	int		bytes_read;
	char	buffer[4096];

	fd = open(filepath, O_RDONLY);
	if (fd < 0)
		return (-1);
	size = 0;
	bytes_read = read(fd, buffer, 4096);
	while (bytes_read > 0)
	{
		size += bytes_read;
		bytes_read = read(fd, buffer, 4096);
	}
	close(fd);
	return (size);
}

char	*ft_read_entire_file(char *filepath)
{
	int		fd;
	int		size;
	char	*content;

	size = ft_get_file_size(filepath);
	if (size < 0)
		return (NULL);
	content = malloc(sizeof(char) * (size + 1));
	if (!content)
		return (NULL);
	fd = open(filepath, O_RDONLY);
	if (fd < 0)
	{
		free(content);
		return (NULL);
	}
	read(fd, content, size);
	content[size] = '\0';
	close(fd);
	return (content);
}
