/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_validate.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aafanasy <aafanasy@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/19 00:54:04 by aafanasy          #+#    #+#             */
/*   Updated: 2026/07/19 00:54:13 by aafanasy         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush02.h"

int	ft_validate_dict(t_dict *dict)
{
	if (!ft_dict_lookup(dict, "0") || !ft_dict_lookup(dict, "1")
		|| !ft_dict_lookup(dict, "2") || !ft_dict_lookup(dict, "3")
		|| !ft_dict_lookup(dict, "4") || !ft_dict_lookup(dict, "5")
		|| !ft_dict_lookup(dict, "6") || !ft_dict_lookup(dict, "7")
		|| !ft_dict_lookup(dict, "8") || !ft_dict_lookup(dict, "9")
		|| !ft_dict_lookup(dict, "10"))
		return (0);
	return (1);
}
