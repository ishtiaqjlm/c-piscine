/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aafanasy <aafanasy@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/19 00:58:27 by aafanasy          #+#    #+#             */
/*   Updated: 2026/07/19 01:13:54 by aafanasy         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush02.h"

int	ft_is_all_zeros(char *str)
{
	while (*str)
	{
		if (*str != '0')
			return (0);
		str++;
	}
	return (1);
}

void	ft_print_magnitude(int zeros, t_dict *dict, t_lang rules)
{
	char	*mag;
	int		i;

	if (zeros == 0)
		return ;
	mag = malloc(zeros + 2);
	if (!mag)
		return ;
	mag[0] = '1';
	i = 1;
	while (i <= zeros)
		mag[i++] = '0';
	mag[i] = '\0';
	ft_putstr(rules.separator);
	ft_putstr(ft_dict_lookup(dict, mag));
	free(mag);
}

void	ft_route_chunk(char *chunk, int pos, t_dict *dict, t_lang rules)
{
	if (pos > 0)
		ft_putstr(rules.comma);
	if (rules.chunk_size == 4)
		ft_print_chunk_asian(chunk, dict, rules);
	else
		ft_print_chunk(chunk, dict, rules);
}

int	ft_print_exact(char *num, t_dict *dict)
{
	char	*exact;

	if (ft_is_magnitude(num))
		return (0);
	exact = ft_dict_lookup(dict, num);
	if (exact)
	{
		ft_putstr(exact);
		ft_putchar('\n');
		return (1);
	}
	return (0);
}

void	ft_convert_and_print(char *num, t_dict *dict, t_lang rules)
{
	int		len;
	int		chunk_len;
	char	*chunk;
	int		pos;

	if (ft_print_exact(num, dict))
		return ;
	len = ft_strlen(num);
	chunk_len = len % rules.chunk_size;
	if (chunk_len == 0)
		chunk_len = rules.chunk_size;
	pos = 0;
	while (pos < len)
	{
		chunk = ft_substr(num, pos, chunk_len);
		if (!ft_is_all_zeros(chunk))
		{
			ft_route_chunk(chunk, pos, dict, rules);
			ft_print_magnitude(len - pos - chunk_len, dict, rules);
		}
		free(chunk);
		pos += chunk_len;
		chunk_len = rules.chunk_size;
	}
	ft_putchar('\n');
}
