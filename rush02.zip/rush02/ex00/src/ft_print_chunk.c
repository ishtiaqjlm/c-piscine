/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_chunk.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aafanasy <aafanasy@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/19 00:59:56 by aafanasy          #+#    #+#             */
/*   Updated: 2026/07/19 01:01:36 by aafanasy         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush02.h"

void	ft_print_units(char c, t_dict *dict)
{
	char	str[2];

	if (c == '0')
		return ;
	str[0] = c;
	str[1] = '\0';
	ft_putstr(ft_dict_lookup(dict, str));
}

void	ft_print_compound_tens(char *s, t_dict *dict, t_lang r)
{
	char	ten[3];
	char	u[2];

	ten[0] = s[0];
	ten[1] = '0';
	ten[2] = '\0';
	u[0] = s[1];
	u[1] = '\0';
	if (r.reverse_tens && s[1] != '0')
	{
		ft_putstr(ft_dict_lookup(dict, u));
		ft_putstr(r.and_word);
		ft_putstr(ft_dict_lookup(dict, ten));
	}
	else
	{
		ft_putstr(ft_dict_lookup(dict, ten));
		if (s[1] != '0')
		{
			ft_putstr(r.hyphen);
			ft_putstr(ft_dict_lookup(dict, u));
		}
	}
}

void	ft_print_tens(char *s, t_dict *dict, t_lang rules)
{
	if (s[0] == '0')
		ft_print_units(s[1], dict);
	else if (s[0] == '1')
		ft_putstr(ft_dict_lookup(dict, s));
	else
		ft_print_compound_tens(s, dict, rules);
}

void	ft_print_chunk(char *chunk, t_dict *dict, t_lang rules)
{
	int	len;

	len = ft_strlen(chunk);
	if (len == 3)
	{
		if (chunk[0] != '0')
		{
			ft_print_units(chunk[0], dict);
			ft_putstr(rules.separator);
			ft_putstr(ft_dict_lookup(dict, "100"));
			if (chunk[1] != '0' || chunk[2] != '0')
				ft_putstr(rules.hundred_and);
		}
		ft_print_tens(chunk + 1, dict, rules);
	}
	else if (len == 2)
		ft_print_tens(chunk, dict, rules);
	else if (len == 1)
		ft_print_units(chunk[0], dict);
}
