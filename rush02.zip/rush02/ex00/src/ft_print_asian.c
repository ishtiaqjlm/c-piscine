/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_asian.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aafanasy <aafanasy@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/19 01:01:48 by aafanasy          #+#    #+#             */
/*   Updated: 2026/07/19 01:04:32 by aafanasy         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush02.h"

char	*ft_build_mag(int zeros, char *buf)
{
	int	k;

	buf[0] = '1';
	k = 1;
	while (k <= zeros)
		buf[k++] = '0';
	buf[k] = '\0';
	return (buf);
}

void	ft_print_chunk_asian(char *chunk, t_dict *dict, t_lang rules)
{
	int		i;
	int		pr;
	int		len;
	char	m[5];

	len = ft_strlen(chunk);
	i = -1;
	pr = 0;
	while (++i < len)
	{
		if (chunk[i] != '0')
		{
			if (pr)
				ft_putstr(rules.separator);
			ft_print_units(chunk[i], dict);
			if (len - i - 1 > 0)
			{
				ft_putstr(rules.separator);
				ft_putstr(ft_dict_lookup(dict, ft_build_mag(len - i - 1, m)));
			}
			pr = 1;
		}
	}
}
