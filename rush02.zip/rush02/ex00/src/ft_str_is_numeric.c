/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_numeric.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aafanasy <aafanasy@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/05 09:05:03 by aafanasy          #+#    #+#             */
/*   Updated: 2026/07/19 00:56:38 by aafanasy         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush02.h"

int	ft_str_is_numeric(char *str)
{
	int	i;

	if (!str || str[0] == '\0')
		return (0);
	i = -1;
	while (str[++i] != '\0')
		if ('0' > str[i] || str[i] > '9')
			return (0);
	return (1);
}

int	ft_is_magnitude(char *str)
{
	int	i;

	if (!str || ft_strlen(str) < 3)
		return (0);
	if (str[0] != '1')
		return (0);
	i = 1;
	while (str[i])
	{
		if (str[i] != '0')
			return (0);
		i++;
	}
	return (1);
}
