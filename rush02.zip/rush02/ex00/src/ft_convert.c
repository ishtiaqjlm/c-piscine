/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_convert.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aafanasy <aafanasy@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/19 00:46:09 by aafanasy          #+#    #+#             */
/*   Updated: 2026/07/19 01:13:57 by aafanasy         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush02.h"

void	ft_apply_custom_rules(t_lang *r, char *dict_path)
{
	if (ft_strstr(dict_path, "japanese") || ft_strstr(dict_path, "chinese"))
	{
		r->chunk_size = 4;
		r->hyphen = " ";
		r->comma = " ";
		r->hundred_and = " ";
	}
	else if (ft_strstr(dict_path, "german"))
	{
		r->separator = "";
		r->reverse_tens = 1;
		r->and_word = "und";
		r->hyphen = "";
		r->comma = " ";
		r->hundred_and = "";
	}
}

t_lang	ft_init_lang_rules(char *dict_path)
{
	t_lang	r;

	r.chunk_size = 3;
	r.separator = " ";
	r.reverse_tens = 0;
	r.and_word = "";
	r.hyphen = "-";
	r.comma = ", ";
	r.hundred_and = " and ";
	if (dict_path)
		ft_apply_custom_rules(&r, dict_path);
	return (r);
}

char	*ft_dict_lookup(t_dict *dict, char *key)
{
	while (dict)
	{
		if (ft_strcmp(dict->key, key) == 0)
			return (dict->value);
		dict = dict->next;
	}
	return (NULL);
}
