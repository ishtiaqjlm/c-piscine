/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aafanasy <aafanasy@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/15 11:04:16 by aafanasy          #+#    #+#             */
/*   Updated: 2026/07/19 01:13:50 by aafanasy         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush02.h"

int	ft_is_sep(char c, char *charset)
{
	int	i;

	i = -1;
	while (charset[++i])
		if (c == charset[i])
			return (1);
	return (0);
}

int	ft_count_words(char *str, char *charset)
{
	int	iword;
	int	i;
	int	count_w;

	iword = 0;
	i = -1;
	count_w = 0;
	while (str[++i])
	{
		if (ft_is_sep(str[i], charset))
			iword = 0;
		if (iword == 0 && !ft_is_sep(str[i], charset))
		{
			iword = 1;
			count_w++;
		}
	}
	return (count_w);
}

int	ft_word_len(char *str, char *charset)
{
	int	len;

	len = 0;
	while (str[len] && !ft_is_sep(str[len], charset))
		len++;
	return (len);
}

char	*ft_write_word(char *str, char *charset)
{
	char	*word;
	int		i;

	word = malloc(sizeof(char) * (ft_word_len(str, charset) + 1));
	if (!word)
		return (NULL);
	i = 0;
	while (str[i] && !ft_is_sep(str[i], charset))
	{
		word[i] = str[i];
		i++;
	}
	word[i] = '\0';
	return (word);
}

char	**ft_split(char *str, char *charset)
{
	int		i;
	char	**str_arr;

	if (!str)
		return (NULL);
	i = 0;
	str_arr = malloc(sizeof(char *) * (ft_count_words(str, charset) + 1));
	if (!str_arr)
		return (NULL);
	while (*str)
	{
		if (ft_is_sep(*str, charset))
		{
			str++;
			continue ;
		}
		str_arr[i++] = ft_write_word(str, charset);
		str += ft_word_len(str, charset);
	}
	str_arr[i] = NULL;
	return (str_arr);
}
