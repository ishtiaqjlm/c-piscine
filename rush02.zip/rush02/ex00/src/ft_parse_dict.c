/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_parse_dict.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aafanasy <aafanasy@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/19 01:02:19 by aafanasy          #+#    #+#             */
/*   Updated: 2026/07/19 01:13:39 by aafanasy         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush02.h"

void	ft_dict_push_back(t_dict **dict, char *key, char *value)
{
	t_dict	*new_node;
	t_dict	*last;

	new_node = malloc(sizeof(t_dict));
	if (!new_node)
		return ;
	new_node->key = key;
	new_node->value = value;
	new_node->next = NULL;
	if (*dict == NULL)
	{
		*dict = new_node;
		return ;
	}
	last = *dict;
	while (last->next != NULL)
		last = last->next;
	last->next = new_node;
}

int	ft_process_dict_line(t_dict **dict, char *line)
{
	char	**parts;
	char	*key;
	char	*value;

	parts = ft_split(line, ":");
	if (!parts || !parts[0] || !parts[1])
	{
		ft_free_split(parts);
		return (0);
	}
	key = ft_strtrim_custom(parts[0]);
	value = ft_strtrim_custom(parts[1]);
	if (!ft_str_is_numeric(key))
	{
		free(key);
		free(value);
		ft_free_split(parts);
		return (0);
	}
	ft_dict_push_back(dict, key, value);
	ft_free_split(parts);
	return (1);
}

int	ft_fill_dict(t_dict **dict, char **lines)
{
	int	i;

	i = 0;
	while (lines[i] != NULL)
	{
		if (ft_strlen(lines[i]) > 0)
		{
			if (ft_process_dict_line(dict, lines[i]) == 0)
				return (0);
		}
		i++;
	}
	return (1);
}

t_dict	*ft_parse_dictionary(char *filepath)
{
	char	*file_content;
	char	**lines;
	t_dict	*dict;

	dict = NULL;
	file_content = ft_read_entire_file(filepath);
	if (!file_content)
		return (NULL);
	lines = ft_split(file_content, "\n");
	free(file_content);
	if (!lines)
		return (NULL);
	if (!ft_fill_dict(&dict, lines))
	{
		ft_free_dictionary(dict);
		ft_free_split(lines);
		return (NULL);
	}
	ft_free_split(lines);
	return (dict);
}
