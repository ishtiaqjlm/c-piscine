/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aafanasy <aafanasy@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/09 16:39:22 by aafanasy          #+#    #+#             */
/*   Updated: 2026/07/19 01:13:47 by aafanasy         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush02.h"

char	*ft_strdup(char *src)
{
	size_t	len_src;
	size_t	i;
	char	*new;

	len_src = 0;
	while (src[len_src])
		len_src++;
	new = malloc((len_src + 1) * sizeof(char));
	if (new == 0)
		return (0);
	i = 0;
	while (i <= len_src)
	{
		new[i] = src[i];
		i++;
	}
	return (new);
}
