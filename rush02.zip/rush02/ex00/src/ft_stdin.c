/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_stdin.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aafanasy <aafanasy@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/19 00:56:58 by aafanasy          #+#    #+#             */
/*   Updated: 2026/07/19 00:57:33 by aafanasy         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush02.h"

void	ft_handle_stdin_line(char *buf, int len, t_dict *dict, t_lang rules)
{
	char	*ptr;

	if (len == 0)
		return ;
	buf[len] = '\0';
	if (ft_str_is_numeric(buf))
	{
		ptr = buf;
		while (*ptr == '0' && *(ptr + 1) != '\0')
			ptr++;
		ft_convert_and_print(ptr, dict, rules);
	}
	else
		ft_putstr("Error\n");
}

void	ft_process_stdin(t_dict *dict, t_lang rules)
{
	char	b[1];
	char	num[4096];
	int		i;

	i = 0;
	while (read(0, b, 1) > 0)
	{
		if (b[0] == '\n')
		{
			ft_handle_stdin_line(num, i, dict, rules);
			i = 0;
		}
		else if (i < 4095)
			num[i++] = b[0];
	}
	ft_handle_stdin_line(num, i, dict, rules);
}
