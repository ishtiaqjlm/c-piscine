/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush02.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aafanasy <aafanasy@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/19 00:45:31 by aafanasy          #+#    #+#             */
/*   Updated: 2026/07/19 00:47:16 by aafanasy         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef RUSH02_H
# define RUSH02_H

# include <unistd.h>
# include <stdlib.h>
# include <fcntl.h>

typedef struct s_dict
{
	char			*key;
	char			*value;
	struct s_dict	*next;
}	t_dict;

typedef struct s_lang
{
	int		chunk_size;
	char	*separator;
	int		reverse_tens;
	char	*and_word;
	char	*hyphen;
	char	*comma;
	char	*hundred_and;
}	t_lang;

// utils
void	ft_putchar(char c);
void	ft_putstr(char *str);
int		ft_strlen(char *str);
int		ft_strcmp(char *s1, char *s2);
int		ft_strncmp(char *s1, char *s2, unsigned int n);
char	*ft_strdup(char *src);
char	**ft_split(char *str, char *charset);
char	*ft_strstr(char *str, char *to_find);
char	*ft_substr(char *s, int start, int len);
int		ft_str_is_numeric(char *str);
int		ft_is_magnitude(char *str);

// parse
char	*ft_read_entire_file(char *filepath);
char	*ft_strtrim_custom(char *str);
int		ft_isspace(char c);
t_dict	*ft_parse_dictionary(char *filepath);
int		ft_process_dict_line(t_dict **dict, char *line);
void	ft_dict_push_back(t_dict **dict, char *key, char *value);

// mamory
void	ft_free_split(char **split_arr);
void	ft_free_dictionary(t_dict *dict);

// convert
t_lang	ft_init_lang_rules(char *dict_path);
char	*ft_dict_lookup(t_dict *dict, char *key);
void	ft_convert_and_print(char *num, t_dict *dict, t_lang rules);

// print
int		ft_is_all_zeros(char *str);
void	ft_print_magnitude(int zeros, t_dict *dict, t_lang rules);
void	ft_print_chunk(char *chunk, t_dict *dict, t_lang rules);
void	ft_print_units(char c, t_dict *dict);
void	ft_print_tens(char *s, t_dict *dict, t_lang rules);
void	ft_print_compound_tens(char *s, t_dict *dict, t_lang r);
void	ft_print_chunk_asian(char *chunk, t_dict *dict, t_lang rules);

// bonus and validation
int		ft_validate_dict(t_dict *dict);
void	ft_process_stdin(t_dict *dict, t_lang rules);

#endif
