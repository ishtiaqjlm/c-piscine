#include <unistd.h>

void ft_ultimate_div_mod(int *c, int *d);

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void ft_putnbr(int n)
{
	long	nb;
	char	c;

	nb = n;
	if (nb < 0)
	{
		ft_putchar('-');
		nb = -nb;
	}
	if (nb >= 10)
	{
		ft_putnbr(nb / 10);
	}
	c = (nb % 10) + '0';
	write(1, &c, 1);
}
int	main(void)
{
	int	a;
	int	b;

	a = 25;
	b = 17;

	ft_ultimate_div_mod(&a, &b);
	ft_putnbr(a);
	write(1, "\n", 1);
	ft_putnbr(b);
	write(1,"Bye!\n",5);
}
