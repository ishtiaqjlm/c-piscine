#include <unistd.h>

int	ft_strlen(char *str);

int	main(void)
{
	int	len;
	char	str[] = "abcdefghi";
	char	c;
	
	len = ft_strlen(str);
	c = len + '0';
	write(1, &c, 1);
	write(1, "\n", 1);
	return 0;
}
