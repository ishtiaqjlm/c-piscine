#include <unistd.h>

void ft_inc(int *ptr)
{
    (*ptr)++;

}

int main(void)
{
    int i;
    int *ptr;
    char c;

    i = 0;
    ptr = &i;
    ft_inc(ptr);
    c = *ptr + '0';
    write(1,&c,1);
    write(1,"\n",1);
}