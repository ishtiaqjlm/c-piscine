#include <unistd.h>

void ft_ft(int *nbr);

int main(void)
{
	int	a;
	char	c;

	a = 10;
	ft_ft(&a);
	c = (a / 10) + '0';
	write(1,&c,1);
	c = (a % 10) + '0';
	write(1, &c, 1);
	write(1, "\n", 1);
	return (0);
}