#include <unistd.h>

void ft_rev_int_tab(int *tab, int size);

int	main(void)
{
	int	tab[] ={2,3,4};
	int	size;

	size=3;
	ft_rev_int_tab(tab, size);
	int	i;
	char	c;

	i = 0;
	while (i < size)
	{
		c = tab[i] + '0';
		write(1, &c, 1);
		i++;
	}
	return 0;
}
