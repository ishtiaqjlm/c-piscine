#include <unistd.h>
void ft_swap(int *a, int *b){

	int	temp;
	temp = *a;
	*a = *b;
	*b = temp;
}

int	main(void){

	int a;
	int	b;
	int c;
	a = 5;
	b = 6;
	ft_swap(&a, &b);
	c = a + '0';
	write(1, &c, 1);
	c = b + '0';
	write(1, &c, 1);
	return 0;
}