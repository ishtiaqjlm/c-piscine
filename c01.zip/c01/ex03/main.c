#include <unistd.h>

void ft_div_mod(int a, int b, int *div, int *mod);

int	main(void)
{
	int	a;
	int	b;
	int	div;
	int	mod;
	char	c;

	a = 10;
	b = 3;
	ft_div_mod(a, b, &div, &mod);
	c = div + '0';
	write(1, &c, 1);
	c = mod + '0';
	write(1, &c, 1);
	write(1, "\n", 1);
}
