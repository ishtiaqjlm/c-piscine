#include <unistd.h>

void	ft_sort_int_tab(int *tab, int size);

int	main(void)
{
	int	tab[] = {3,2,1};
	int	size;
	int	i;
	char	c;

	size=3;
	ft_sort_int_tab(tab,size);
	i = 0;
	while(i<size)
	{
		c = tab[i] + '0';
		write(1,&c,1);
		i++;
	}
	write(1,"\n",1);
}
