/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_prime.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/15 17:36:55 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/07/16 18:46:51 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

int	ft_is_prime(int nb)
{
	int		i;
	long	n;

	n = nb;
	if (n < 2)
		return (0);
	i = 2;
	while ((i * i) <= n)
	{
		if (n % i == 0)
			return (0);
		i++;
	}
	return (1);
}
/*
void	ft_putnbr(int n)
{
	long	nb;
	char	c;

	nb = n;
	if(nb < 0)
	{
		write(1,"-",1);
		nb = -nb;
	}
	if(nb > 9)
		ft_putnbr(nb / 10);
	c = nb % 10 + '0';
	write(1, &c, 1);	
}
int	main(void)
{
	int	nb;
	int	result;
	char	print;

	nb = 5;
	result = ft_is_prime(nb);
	print = result + '0';
	write(1, &print, 1);
	return (0);
}*/
