/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_find_next_prime.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/16 14:30:30 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/07/16 18:47:28 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

int	ft_is_prime(int nb)
{
	long	n;
	int		i;

	n = nb;
	if (n < 2)
		return (0);
	i = 2;
	while ((i * i) <= n)
	{
		if (n % i == 0)
			return (0);
		i++;
	}
	return (1);
}

int	ft_find_next_prime(int nb)
{
	long	n;

	n = nb;
	while (!(ft_is_prime(n)))
		n++;
	return (n);
}
/*
void	ft_putnbr(int n)
{
	long	nb;
	char	c;

	nb = n;
	if (nb < 0)
	{
		write(1, "-", 1);
	}
	if ( nb > 9)
		ft_putnbr(nb / 10);
	c = nb % 10 + '0';
	write(1, &c, 1);
}
int	main(void)
{
	int	nb;
	int	result;

	nb = 48;
	result = ft_find_next_prime(nb);
	ft_putnbr(result);
}
*/
