/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_recursive_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/14 18:29:29 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/07/16 18:41:04 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

int	ft_recursive_power(int nb, int power)
{
	if (power < 0)
		return (0);
	if (power == 0)
		return (1);
	return (nb * ft_recursive_power(nb, (power - 1)));
}
/*
#include <stdio.h>
int	main(void)
{
	int	nb;
	int	power;
	int	result;

	nb = 0;
	power = 0;
	result = ft_recursive_power(nb, power);
	printf("number 0 with power 0.result is %d\n", result);
	return (0);
}*/
