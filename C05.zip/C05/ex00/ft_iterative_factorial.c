/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/13 16:04:23 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/07/16 18:28:11 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

int	ft_iterative_factorial(int nb)
{
	int	result;

	if (nb < 0)
		return (0);
	result = 1;
	while (nb > 0)
	{
		result = result * nb;
		nb --;
	}
	return (result);
}
/*
#include <stdio.h>
int main(void)
{
	int	nb;
	int	result;
	
	nb = 5;
	result = ft_iterative_factorial(nb);
	printf("fatorial of 5 is %d\n",result);
}*/
