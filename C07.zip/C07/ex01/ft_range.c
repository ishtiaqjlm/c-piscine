/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/19 17:29:06 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/07/19 18:36:37 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	*ft_range(int min, int max)
{
	int	size;
	int	i;
	int	*drange;

	i = 0;
	if (min >= max)
		return (NULL);
	size = max - min;
	drange = malloc(size * sizeof(int));
	if (drange == NULL)
		return (NULL);
	while (min < max)
	{
		drange[i] = min;
		min++;
		i++;
	}
	return (drange);
}
/*
int	main(void)
{
	int min = 4;
	int max = 9;
	int *range;
	range = ft_range(min,max);
	int i=0;
	while(i < (max - min))
	{
		printf("Number is %d\n", range[i]);
		i ++;
	}
	free(range);
}*/
