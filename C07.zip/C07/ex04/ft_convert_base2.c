/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_convert_base2.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/21 12:11:10 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/07/23 13:40:11 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdlib.h>

int		ft_strlen(char *str);
int		ft_char_index(char c, char *base);
int		ft_count_digits(int nbr, int base_len);
int		ft_isspace(char c);

int	ft_check_base(char *base)
{
	int	i;
	int	j;

	i = 0;
	while (base[i])
	{
		if (base[i] == '+' || base[i] == '-')
			return (0);
		j = i + 1;
		while (base[j])
		{
			if (base[i] == base[j])
				return (0);
			j++;
		}
		i++;
	}
	if (i < 2)
		return (0);
	return (1);
}

int	ft_get_sign(char *nbr, int *i)
{
	int	sign;

	sign = 1;
	while (ft_isspace(nbr[*i]))
		(*i)++;
	while (nbr[*i] == '+' || nbr[*i] == '-')
	{
		if (nbr[*i] == '-')
			sign = -sign;
		(*i)++;
	}
	return (sign);
}

int	ft_atoi_base(char *nbr, char *base)
{
	int	result;
	int	base_len;
	int	value;
	int	i;
	int	sign;

	if (!ft_check_base(base))
		return (0);
	base_len = ft_strlen(base);
	result = 0;
	i = 0;
	sign = ft_get_sign(nbr, &i);
	while (nbr[i])
	{
		value = ft_char_index(nbr[i], base);
		if (value == -1)
			break ;
		result = result * base_len + value;
		i++;
	}
	return (result * sign);
}

void	ft_fill_base(int nbr, char *base, char *str, int *index)
{
	int	base_len;

	base_len = ft_strlen(base);
	if (nbr >= base_len)
		ft_fill_base(nbr / base_len, base, str, index);
	str[*index] = base[nbr % base_len];
	(*index)++;
}

char	*ft_putnbr_base(int nbr, char *base)
{
	char	*str;
	int		base_len;
	int		digits;
	int		index;

	if (!ft_check_base(base))
		return (NULL);
	base_len = ft_strlen(base);
	digits = ft_count_digits(nbr, base_len);
	str = malloc(sizeof(char) * (digits + 1));
	if (str == NULL)
		return (NULL);
	index = 0;
	if (nbr < 0)
	{
		str[index] = '-';
		index++;
		nbr = -nbr;
	}
	ft_fill_base(nbr, base, str, &index);
	str[index] = '\0';
	return (str);
}
