/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_convert_base.h                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/21 13:35:59 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/07/23 11:35:51 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#ifndef FT_CONVERT_BASE_H
# define FT_CONVERT_BASE_H

# include <unistd.h>
# include <stdlib.h>

int		ft_check_base(char *base);
int		ft_get_sign(char *nbr, int *i);
int		ft_strlen(char *str);
int		ft_char_index(char c, char *base);
int		ft_atoi_base(char *nbr, char *base);
char	*ft_putnbr_base(int nbr, char *base);
int		ft_count_digits(int nbr, int base_len);
int		ft_isspace(char c);
void	ft_fill_base(int nbr, char *base, char *str, int *index);
#endif
