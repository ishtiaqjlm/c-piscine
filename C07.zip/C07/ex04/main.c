#include <stdio.h>
#include <stdlib.h>

int     main(void)
{
        char *converted;
        converted = ft_convert_base("1010", "01", "0123456789");
        printf("%s\n", converted);
        printf("Decimal -> Binary%s\n", ft_convert_base("42", "0123456789", "01"));
        printf("Binary -> decimal%s\n", ft_convert_base("101010", "01", "0123456789"));
        printf("Decimal -> Hexa%s\n", ft_convert_base("42", "0123456789", "0123456789ABCDEF"));
        printf("Hexa -> Decimal%s\n", ft_convert_base("2A", "0123456789ABCDEF", "0123456789"));
        printf("Negative Number%s\n", ft_convert_base("-42", "0123456789", "01"));
        printf("Zero%s\n", ft_convert_base("0", "0123456789", "01"));
        printf("Bad Base%s\n", ft_convert_base("42", "01234+", "01"));
        printf("Test INT_MIN%s\n",ft_convert_base("-2147483648","0123456789","0123456789ABCDEF"));
        free(converted);
        return (0);
}

