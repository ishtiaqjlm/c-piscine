/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_convert_base.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/21 12:10:22 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/07/23 13:42:58 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdlib.h>

int		ft_check_base(char *base);
int		ft_get_sign(char *nbr, int *i);
int		ft_atoi_base(char *nbr, char *base);
char	*ft_putnbr_base(int nbr, char *base);
void	ft_fill_base(int nbr, char *base, char *str, int *index);

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
		i++;
	return (i);
}

int	ft_char_index(char c, char *base)
{
	int	i;

	i = 0;
	while (base[i])
	{
		if (base[i] == c)
			return (i);
		i++;
	}
	return (0);
}

int	ft_isspace(char c)
{
	if (c == ' ' || (c >= 9 && c <= 13))
		return (1);
	return (0);
}

int	ft_count_digits(int nbr, int base_len)
{
	int	digits;

	digits = 0;
	while (nbr != 0)
	{
		nbr = nbr / base_len;
		digits++;
	}
	return (digits);
}

char	*ft_convert_base(char *nbr, char *base_from, char *base_to)
{
	int		number;
	char	*result;

	if (!ft_check_base(base_from) || !ft_check_base(base_to))
		return (NULL);
	number = ft_atoi_base(nbr, base_from);
	result = ft_putnbr_base(number, base_to);
	return (result);
}
