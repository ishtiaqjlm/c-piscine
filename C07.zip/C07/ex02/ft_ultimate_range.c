/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/23 11:26:58 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/07/23 11:29:00 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_ultimate_range(int **range, int min, int max)
{
	int	size;
	int	i;

	if (min >= max)
	{
		*range = NULL;
		return (0);
	}
	i = 0;
	size = max - min;
	*range = malloc(size * sizeof(int));
	while (min < max)
	{
		(*range)[i] = min;
		min++;
		i++;
	}
	return (size);
}
/*
int	main(void)
{
	int min = 4;
	int max = 9;
	int	*range;
	int	size;
	int	i;

	range = NULL;
	size = ft_ultimate_range(&range, min, max);

	i = 0;
	while (i < size)
	{
		printf("Number is %d\n", range[i]);
		i++;
	}
	free(range);
	return (0);

}*/
