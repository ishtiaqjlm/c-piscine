/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/22 17:36:47 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/07/22 18:22:25 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdlib.h>

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		i++;
	}
	return (i);
}

int	ft_total_len(int size, char **strs, char *sep)
{
	int	i;
	int	len;

	i = 0;
	len = 0;
	while (i < size)
	{
		len += ft_strlen(strs[i]);
		if (i < size - 1)
			len += ft_strlen(sep);
		i++;
	}
	return (len);
}

void	ft_copy_str(char *dest, char *src, int *index)
{
	int	i;

	i = 0;
	while (src[i])
	{
		dest[*index] = src[i];
		(*index)++;
		i++;
	}
}

char	*ft_strjoin(int size, char **strs, char *sep)
{
	char	*result;
	int		index;
	int		i;

	if (size == 0)
	{
		result = malloc(1);
		if (result)
			result[0] = '\0';
		return (result);
	}
	result = malloc(ft_total_len(size, strs, sep) + 1);
	if (!result)
		return (NULL);
	index = 0;
	i = 0;
	while (i < size)
	{
		ft_copy_str(result, strs[i], &index);
		if (i < size - 1)
			ft_copy_str(result, sep, &index);
		i++;
	}
	result[index] = '\0';
	return (result);
}
/*
#include <stdio.h>
int main()
{
	char	*strs[] = {"Hello", "42", "Prague"};
	char	*result;
	result = ft_strjoin(3, strs, "+");
	printf("%s\n", result);
	free(result);
}*/
