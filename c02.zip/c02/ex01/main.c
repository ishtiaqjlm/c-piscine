#include <unistd.h>

char *ft_strncpy(char *dest, char *src, unsigned int n);

int main(void)
{
    char    s_src[]="ab";
    char    s_dest[4];
    char    *result;
    unsigned int	n;

    n = 4;
    result = ft_strncpy(s_dest, s_src, n);
    unsigned int i = 0;
    while(i < n)
    {
        write(1,&result[i],1);
        if(result[i] == '\0')
        {
            write(1," Null ",6);
        }
        i++;
    }
    write(1,"\n",1);
}
