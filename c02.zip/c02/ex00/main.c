#include <unistd.h>

char *ft_strcpy(char *dest, char *src);

int main(void)
{
    char    s_src[]="abc";
    char    s_dest[4];
    char    *result;
    result = ft_strcpy(s_dest,s_src);
    write(1, &result[0], 1);
    write(1, &result[1], 1);
    write(1, &result[2], 1);
    //write(1, &result[3], 1);
    write(1, &"\n", 1);
}