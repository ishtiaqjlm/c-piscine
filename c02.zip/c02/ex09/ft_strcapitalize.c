/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/07 16:55:10 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/07/07 18:39:42 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

char	do_uppercase(char str)
{
	if (str >= 'a' && str <= 'z')
	{
		str = str - 32;
	}
	return (str);
}

char	do_lowercase(char str)
{
	if (str >= 'A' && str <= 'Z')
	{
		str = str + 32;
	}
	return (str);
}

int	is_alphanumeric(char str)
{
	if ((str >= 'a' && str <= 'z')
		|| (str >= 'A' && str <= 'Z')
		|| (str >= '0' && str <= '9'))
	{
		return (1);
	}
	return (0);
}

char	*ft_strcapitalize(char *str)
{
	int	i;
	int	prv_index;

	i = 0;
	while (str[i] != '\0')
	{
		if (i == 0)
		{
			str[i] = do_uppercase(str[i]);
		}
		else
		{
			prv_index = i - 1;
			if (is_alphanumeric(str[prv_index]))
				str[i] = do_lowercase(str[i]);
			else
				str[i] = do_uppercase(str[i]);
		}
		i++;
	}
	return (str);
}
/*
int	main(void)
{
	char	test[] = "hi, how are you? 42words forty-two; fifty+and+one";
	ft_strcapitalize(test);
	write(1, test, 49);
	return (0);
}*/
