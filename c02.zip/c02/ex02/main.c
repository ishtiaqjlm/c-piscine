#include <unistd.h>

int ft_str_is_alpha(char *str);

int main(void)
{
    char *str = "ABc1";

    if(ft_str_is_alpha(str))
        write(1,"Yes",3);
    else
        write(1,"No",2);
    write(1,"\n",1);
}
