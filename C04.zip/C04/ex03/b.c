/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/09 16:44:46 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/07/09 19:02:39 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

int	is_space(char c)
{
	if (c == ' ' || c == '\t'
		|| c == '\n'
		|| c == '\v'
		|| c == '\f'
		|| c == '\r')
		return (1);
	return (0);
}

unsigned int	ft_putlen(char *str)
{
	int	i;
	int	nbrlen;
	char	c;

	i = 0;
	nbrlen = 0;
	while (str[i] != '\0')
	{
		c = str[i];
		i++;
	}
}

int	ft_atoi(char *str)
{
	int	i;
	int	j;

	i = 0;
	j = 0;
	while (str[i] != '\0')
	{
		if (str[i] == '-')
			j++;
		i++;
	}
	return (j);
}

int	main(void)
{
	char	*str;
	char	print;
	int	result;
	str = "---+--+1234ab567";
	result = ft_atoi(str);
	print = result + '0';
	write(1, &print, 1);
}
