/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/09 12:06:55 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/07/11 13:47:41 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

void	ft_putnbr(int nb)
{
	char	negative;

	if (nb == -2147483648)
	{
		write(1, "-2147483648", 11);
		return ;
	}
	if (nb < 0)
	{
		negative = '-';
		write(1, &negative, 1);
		nb = -nb;
	}
	if (nb / 10 > 0)
	{
		ft_putnbr(nb / 10);
	}
	negative = (nb % 10) + '0';
	write(1, &negative, 1);
}
/*
int	main(void)
{
	ft_putnbr(0);
	write(1,"\n",1);
	ft_putnbr(123);
        write(1,"\n",1);
	ft_putnbr(-123);
	write(1,"\n",1);
}*/
