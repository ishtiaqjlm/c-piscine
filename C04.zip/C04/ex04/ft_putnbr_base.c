/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_base.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/13 12:10:10 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/07/13 13:30:29 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
		i++;
	return (i);
}

void	ft_putnbr_base_recursive(long n, char *base, int base_len)
{
	if (n >= base_len)
		ft_putnbr_base_recursive(n / base_len, base, base_len);
	write(1, &base[n % base_len], 1);
}

int	ft_valid_base(char *base)
{
	int	i;
	int	j;

	i = 0;
	while (base[i])
	{
		if (base[i] == '+' || base[i] == '-')
			return (0);
		j = i + 1;
		while (base[j])
		{
			if (base[i] == base[j])
				return (0);
			j++;
		}
		i++;
	}
	if (i < 2)
		return (0);
	return (1);
}

void	ft_putnbr_base(int nbr, char *base)
{
	char	negative;
	long	n;
	int		base_len;

	if (!ft_valid_base(base))
		return ;
	n = (long)nbr;
	if (n < 0)
	{
		negative = '-';
		write(1, &negative, 1);
		n = -n;
	}
	base_len = ft_strlen(base);
	ft_putnbr_base_recursive(n, base, base_len);
}
/*
int	main(void)
{
	ft_putnbr_base(17,"0123456789ABCDEF"); //hexadecimal
        write(1,"\n",1);
	ft_putnbr_base(3,"01"); //binary
	write(1,"\n",1);
}*/
