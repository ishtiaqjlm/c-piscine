/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/08 14:27:26 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/07/08 18:42:04 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

char	*ft_strstr(char *str, char *to_find)
{
	int	i;
	int	j;

	if (to_find[0] == '\0')
		return (str);
	i = 0;
	while (str[i])
	{
		j = 0;
		while (str[i + j] == to_find[j] && to_find[j])
			j++;
		if (to_find[j] == '\0')
			return (&str[i]);
		i++;
	}
	return (0);
}
/*
int	main(void)
{
	char	str[] = "Hello World";
	char	to_find[] = "o";

	char	*result;
	int	i;
	
	i = 0;
	result = ft_strstr(str, to_find);
	if(result)
	{
		while (result[i] != '\0')
        	{
                	write(1,&result[i],1);
                	i++;
        	}
	}
	else
		write(1,"Not found",9);
	write(1,"\n",1);
}*/
