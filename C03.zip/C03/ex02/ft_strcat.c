/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcat.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/08 12:26:04 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/07/08 12:57:09 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

char	*ft_strcat(char *dest, char *src)
{
	int	i;
	int	j;

	i = 0;
	j = 0;
	while (dest[i])
		i++;
	while (src[j])
	{
		dest[i] = src[j];
		i++;
		j++;
	}
	dest[i] = '\0';
	return (dest);
}
/*
int	main(void)
{
	char	src[] = "World";
	char	dest[11] = "Hello ";
	char	*result;
	int	i;
	result = ft_strcat(dest, src);

	i = 0;
	while (result[i] != '\0')
	{
		write(1,&result[i],1);
		i++;
	}
	write(1,"\n",1);	
}
*/
