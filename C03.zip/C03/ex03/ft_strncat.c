/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/08 13:04:56 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/07/08 14:14:29 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

char	*ft_strncat(char *dest, char *src, unsigned int nb)
{
	unsigned int	i;
	unsigned int	j;

	i = 0;
	j = 0;
	while (dest[i])
		i++;
	while (src[j] && j < nb)
	{
		dest[i] = src[j];
		i++;
		j++;
	}
	dest[i] = '\0';
	return (dest);
}
/*
int	main(void)
{
	char	src[] = "World";
	char	dest[20] = "Hello ";
	char	*result;
	int	i;
	unsigned int	nb;

	nb = 4;
	result = ft_strncat(dest, src, nb);

	i = 0;
	while (result[i] != '\0')
	{
		write(1,&result[i],1);
		i++;
	}
	write(1,"\n",1);		
}*/
