/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncmp.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <ishtiahm@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/08 11:29:53 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/07/08 18:39:20 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

int	ft_strncmp(char *s1, char *s2, unsigned int n)
{
	unsigned int	i;

	i = 0;
	while (s1[i] == s2[i] && s1[i] && i < n)
		i++;
	if (i == n)
		return (0);
	return ((unsigned char)s1[i] - (unsigned char)s2[i]);
}
/*
int	main(void)
{
	char	s1[] = "hello";
	char	s2[] = "hllo";
	unsigned int	n;
	int	result;

	n=4;
	result = ft_strncmp(s1,s2,n);

	if (result > 0)
		write(1,"s1 > s2",7);
	else if (result < 0)
		write(1,"s1 < s2",7);
	else
		write(1,"equal",5);
	write(1,"\n",1);
}
*/
