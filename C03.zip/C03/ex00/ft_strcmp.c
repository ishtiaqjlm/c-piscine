/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishtiahm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/08 10:15:10 by ishtiahm          #+#    #+#             */
/*   Updated: 2026/07/08 11:28:27 by ishtiahm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_strcmp(char *s1, char *s2)
{
	int	i;

	i = 0;
	while (s1[i] && s1[i] == s2[i])
		i++;
	return ((unsigned char)s1[i] - (unsigned char)s2[i]);
}
/*
int	main(void)
{
	char s1[] = "hello";
	char s2[] = "hello";
	int	result;

	result = ft_strcmp(s1,s2);
	if (result > 0)
		write(1,"s1 > s2",7);
	else if (result < 0)
		write(1,"s1 < s2",7);
	else
		write(1,"equal",5);
	write(1,"\n",1);

}*/
